#!/usr/bin/env python3
if __name__ == '__main__':
    import sys
    rc = 1
    try:
        import venv
        venv.main()
        rc = 0
    except Exception as e:
        print('Error: %s' % e, file=sys.stderr)
    sys.exit(rc)
